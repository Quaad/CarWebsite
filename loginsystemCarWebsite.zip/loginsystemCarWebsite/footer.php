<footer>
  <!-- footer -->
   <div class="container fluid padding">
     <div class="row text-center">
         <div class="col-12">
             <img src="assets/logoFooter.png" class="hvr-bob" alt="">
             <hr>
               <p>555-555-555</p>
               <p>email@</p>
               <p>street</p>
               <p>city, 000000</p>
               <div></div>
         </div>
         <div class="col-12">
           <hr>
           <h5>&copy; QuaadCars</h5>
         </div>
     </div>
   </div>
</footer>
</body>
</html>
